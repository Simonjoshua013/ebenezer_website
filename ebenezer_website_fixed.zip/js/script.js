
console.log("Ebenezer School Website Loaded");
